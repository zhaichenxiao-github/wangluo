package com.example.mvplibrary.view;

public interface BaseView {

}
