package com.example.mvplibrary.model;

public interface BaseModel {
}
